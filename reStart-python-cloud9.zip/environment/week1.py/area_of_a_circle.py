#calculate the area of a circle=>3.14 *r*r
def areaOfCircle(x,y):
    print("area of a circle:", x*y*y)
    x=3.14
    y=48
    
    # print("multiplication is:", x*y*z)

areaOfCircle(3.14,48)

#area of a cirle
def area(rad):
    return 3.14*rad*rad
print("area of a circle :",+ area(10))


#circumference of a circle=>2*3.14*rad*rad
def cir_of_a_circle(rad):
    return 2*3.14*rad*rad
print("circumference of a circle :",+ cir_of_a_circle(9))


#area of a triangle
    
def triangle(base,height):
    return 0.5*base*height
print("Area of a triangle :",triangle(8,10))
    