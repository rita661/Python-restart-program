print('my name is rita tunde')
print('my hobbies include: cooking, driving and reading')
  
