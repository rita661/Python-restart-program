#for loop- initialization, condition, increment/decrement
x=5
while x<11:
    print(x)
    x=x+1

