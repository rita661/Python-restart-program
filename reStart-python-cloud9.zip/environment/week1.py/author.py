print('hello world')

bookname="Python Programming"
price=400
authorname="Mr peter"
result=90.67
flag=True
number=5j


print(type(bookname),type(result),type(flag),type(number))
print(type(price))
print(type(authorname))

print(id(bookname))
print(id(price))

number=10
print(id(number))

number=20
print(id(number))






