print("Python has three numeric types: int, float, and complex")
print("")

examplesofint=5
examplesoffloat=3.2
examplesofcomplex=5.2j

myValue=True
print(myValue)
print(type(myValue))
print(str(myValue) + " is of the data type " + str(type(myValue)))
print("")

print("integers:",examplesofint)
print("float:",examplesoffloat)
print("complex:",examplesofcomplex)

