#loops
import random

number = random.randint(45,100)
flag==false

