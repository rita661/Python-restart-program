#list
myFruitList = ["apple", "banana", "cherry", "orange", "grapes", "strawberry"]
print(myFruitList)
print(type(myFruitList))

#Accessing a list by position
print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])
print(myFruitList[3])
print(myFruitList[4])
print(myFruitList[5])
print()

myWishList = ["Get a solution architect job", "By Sept 2022", "in Bristol."]
print(myWishList)

#Changing the values in a list
myFruitList[2] = "pineapple"
print(myFruitList)

#introducing tuple
myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))


#Accessing a tuple by position
print(myFinalAnswerTuple[1])

#Introducing the dictionary data type
myFavoriteStudentDictionary = {
  "Ubah" : "Mohammed", 
  "Afzal" : "Maruf",
  "Isa" : "Caliste",
  "Rita" : "Tunde"
}
print(myFavoriteStudentDictionary)


