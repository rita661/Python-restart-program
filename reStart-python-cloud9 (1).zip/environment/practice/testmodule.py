from mod1 import area
from mod1 import circumference
from mod1 import triangle
from mod1 import square
from mod1 import peri_square
from mod1 import area_rectangle

print("area of a cirle:", + area(50))
print("circumference of a circle :", + circumference(20))
print("area of a triangle :", + triangle(8,6))
print("area of a square : ", + square(8))
print("perimeter of a square :", + peri_square(10))
print("area of a rectangle :", + area_rectangle(10,20))