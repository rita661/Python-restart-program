import math
#Area of shapes:circle, triangle, square and circumference of a circle.
#area of a circle
def area(rad):
    return math.pi*rad*rad
#circumference of a circle
def circumference(rad):
    return 2 *math.pi * rad*rad
    
#area of atriangle
def triangle(base,height):
    return 0.5*base*height
#area of a square
def square(a):
    return a**a
#perimetre of a square
def peri_square(a):
    return 4 *a
#area of a rectangle
def area_rectangle(l,b):
    return l*b